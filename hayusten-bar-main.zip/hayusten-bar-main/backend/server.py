from fastapi import FastAPI, APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, timezone
import hashlib
import jwt
from passlib.context import CryptContext

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Security
SECRET_KEY = "sua_chave_secreta_aqui_mude_em_producao"
ALGORITHM = "HS256"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Create the main app
app = FastAPI(title="Sistema de Gestão de Bar")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Models
class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    nome: str
    email: str
    role: str = "caixa"  # admin, gerente, caixa, armazem
    password_hash: str
    activo: bool = True

class UserCreate(BaseModel):
    nome: str
    email: str
    password: str
    role: str = "caixa"

class UserLogin(BaseModel):
    email: str
    password: str

class Product(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    nome: str
    categoria: str
    preco_venda: float
    stock_atual: int = 0
    stock_minimo: int = 5
    activo: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProductCreate(BaseModel):
    nome: str
    categoria: str
    preco_venda: float
    stock_atual: int = 0
    stock_minimo: int = 5

class InventoryMovement(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    product_id: str
    tipo: str  # COMPRA, VENDA, AJUSTE_POSITIVO, AJUSTE_NEGATIVO, QUEBRA
    quantidade: int
    motivo: str = ""
    user_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SaleItem(BaseModel):
    product_id: str
    product_name: str
    quantidade: int
    preco_unit: float
    total_linha: float

class Sale(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    data: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    user_id: str
    items: List[SaleItem]
    total_bruto: float
    desconto: float = 0
    total_liquido: float
    metodo_pagamento: str = "dinheiro"  # dinheiro, cartao, mpesa
    estado: str = "finalizada"

class SaleCreate(BaseModel):
    items: List[SaleItem]
    desconto: float = 0
    metodo_pagamento: str = "dinheiro"

class StockAdjustment(BaseModel):
    product_id: str
    quantidade: int
    motivo: str
    tipo: str  # AJUSTE_POSITIVO, AJUSTE_NEGATIVO, QUEBRA

# Auth functions
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(user_id: str, email: str) -> str:
    payload = {"user_id": user_id, "email": email}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("user_id")
        if not user_id:
            raise HTTPException(status_code=401, detail="Token inválido")
        
        user = await db.users.find_one({"id": user_id})
        if not user:
            raise HTTPException(status_code=401, detail="Utilizador não encontrado")
        
        return User(**user)
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Token inválido")

# Auth Routes
@api_router.post("/auth/register")
async def register_user(user_data: UserCreate):
    # Check if user already exists
    existing_user = await db.users.find_one({"email": user_data.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email já registado")
    
    # Create user
    hashed_password = hash_password(user_data.password)
    user = User(
        nome=user_data.nome,
        email=user_data.email,
        role=user_data.role,
        password_hash=hashed_password
    )
    
    await db.users.insert_one(user.dict())
    return {"message": "Utilizador criado com sucesso", "user_id": user.id}

@api_router.post("/auth/login")
async def login_user(login_data: UserLogin):
    user = await db.users.find_one({"email": login_data.email})
    if not user or not verify_password(login_data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenciais inválidas")
    
    if not user["activo"]:
        raise HTTPException(status_code=401, detail="Conta desactivada")
    
    token = create_access_token(user["id"], user["email"])
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "nome": user["nome"],
            "email": user["email"],
            "role": user["role"]
        }
    }

# Product Routes
@api_router.get("/products", response_model=List[Product])
async def get_products(current_user: User = Depends(get_current_user)):
    products = await db.products.find({"activo": True}).to_list(1000)
    return [Product(**product) for product in products]

@api_router.post("/products", response_model=Product)
async def create_product(product_data: ProductCreate, current_user: User = Depends(get_current_user)):
    if current_user.role not in ["admin", "gerente"]:
        raise HTTPException(status_code=403, detail="Sem permissões")
    
    product = Product(**product_data.dict())
    await db.products.insert_one(product.dict())
    return product

@api_router.put("/products/{product_id}")
async def update_product(product_id: str, product_data: ProductCreate, current_user: User = Depends(get_current_user)):
    if current_user.role not in ["admin", "gerente"]:
        raise HTTPException(status_code=403, detail="Sem permissões")
    
    result = await db.products.update_one(
        {"id": product_id},
        {"$set": product_data.dict()}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    
    return {"message": "Produto actualizado"}

# Stock Routes
@api_router.post("/stock/adjust")
async def adjust_stock(adjustment: StockAdjustment, current_user: User = Depends(get_current_user)):
    if current_user.role not in ["admin", "gerente", "armazem"]:
        raise HTTPException(status_code=403, detail="Sem permissões")
    
    # Get product
    product = await db.products.find_one({"id": adjustment.product_id})
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    
    # Create inventory movement
    movement = InventoryMovement(
        product_id=adjustment.product_id,
        tipo=adjustment.tipo,
        quantidade=adjustment.quantidade,
        motivo=adjustment.motivo,
        user_id=current_user.id
    )
    
    # Update stock
    new_stock = product["stock_atual"]
    if adjustment.tipo == "AJUSTE_POSITIVO":
        new_stock += adjustment.quantidade
    elif adjustment.tipo in ["AJUSTE_NEGATIVO", "QUEBRA"]:
        new_stock -= adjustment.quantidade
    
    if new_stock < 0:
        raise HTTPException(status_code=400, detail="Stock não pode ser negativo")
    
    # Save changes
    await db.inventory_movements.insert_one(movement.dict())
    await db.products.update_one(
        {"id": adjustment.product_id},
        {"$set": {"stock_atual": new_stock}}
    )
    
    return {"message": "Ajuste de stock realizado", "novo_stock": new_stock}

# Sales Routes
@api_router.post("/sales", response_model=Sale)
async def create_sale(sale_data: SaleCreate, current_user: User = Depends(get_current_user)):
    # Calculate totals
    total_bruto = sum(item.total_linha for item in sale_data.items)
    total_liquido = total_bruto - sale_data.desconto
    
    # Check stock availability
    for item in sale_data.items:
        product = await db.products.find_one({"id": item.product_id})
        if not product:
            raise HTTPException(status_code=404, detail=f"Produto {item.product_name} não encontrado")
        
        if product["stock_atual"] < item.quantidade:
            raise HTTPException(
                status_code=400, 
                detail=f"Stock insuficiente para {item.product_name}. Disponível: {product['stock_atual']}"
            )
    
    # Create sale
    sale = Sale(
        user_id=current_user.id,
        items=sale_data.items,
        total_bruto=total_bruto,
        desconto=sale_data.desconto,
        total_liquido=total_liquido,
        metodo_pagamento=sale_data.metodo_pagamento
    )
    
    # Process stock movements and update stock
    for item in sale_data.items:
        # Create inventory movement
        movement = InventoryMovement(
            product_id=item.product_id,
            tipo="VENDA",
            quantidade=-item.quantidade,
            motivo="Venda",
            user_id=current_user.id
        )
        await db.inventory_movements.insert_one(movement.dict())
        
        # Update product stock
        await db.products.update_one(
            {"id": item.product_id},
            {"$inc": {"stock_atual": -item.quantidade}}
        )
    
    # Save sale
    await db.sales.insert_one(sale.dict())
    return sale

@api_router.get("/sales")
async def get_sales(current_user: User = Depends(get_current_user)):
    sales = await db.sales.find().sort("data", -1).limit(100).to_list(100)
    
    # Convert MongoDB ObjectId to strings and clean data
    clean_sales = []
    for sale in sales:
        # Remove MongoDB's _id field
        if "_id" in sale:
            del sale["_id"]
        clean_sales.append(sale)
    
    return clean_sales

# Dashboard Routes
@api_router.get("/dashboard/summary")
async def get_dashboard_summary(current_user: User = Depends(get_current_user)):
    today = datetime.now(timezone.utc).date()
    start_of_day = datetime.combine(today, datetime.min.time()).replace(tzinfo=timezone.utc)
    end_of_day = datetime.combine(today, datetime.max.time()).replace(tzinfo=timezone.utc)
    
    # Sales today
    sales_today = await db.sales.find({
        "data": {"$gte": start_of_day, "$lte": end_of_day}
    }).to_list(1000)
    
    total_vendas_hoje = sum(sale["total_liquido"] for sale in sales_today)
    num_vendas = len(sales_today)
    ticket_medio = total_vendas_hoje / num_vendas if num_vendas > 0 else 0
    
    # Top products today
    product_sales = {}
    for sale in sales_today:
        for item in sale["items"]:
            if item["product_id"] not in product_sales:
                product_sales[item["product_id"]] = {
                    "nome": item["product_name"],
                    "quantidade": 0,
                    "valor": 0
                }
            product_sales[item["product_id"]]["quantidade"] += item["quantidade"]
            product_sales[item["product_id"]]["valor"] += item["total_linha"]
    
    top_products = sorted(product_sales.values(), key=lambda x: x["quantidade"], reverse=True)[:5]
    
    # Stock alerts
    products = await db.products.find({"activo": True}).to_list(1000)
    stock_alerts = [p for p in products if p["stock_atual"] <= p["stock_minimo"]]
    
    return {
        "data": today.isoformat(),
        "vendas_hoje": round(total_vendas_hoje, 2),
        "num_vendas": num_vendas,
        "ticket_medio": round(ticket_medio, 2),
        "top_products": top_products,
        "alertas_stock": len(stock_alerts),
        "produtos_em_ruptura": [{"nome": p["nome"], "stock": p["stock_atual"]} for p in stock_alerts]
    }

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()

# Create default admin user on startup
@app.on_event("startup")
async def create_default_admin():
    admin_exists = await db.users.find_one({"role": "admin"})
    if not admin_exists:
        admin_user = User(
            nome="Administrador",
            email="admin@bar.com",
            role="admin",
            password_hash=hash_password("admin123")
        )
        await db.users.insert_one(admin_user.dict())
        logger.info("Utilizador admin criado: admin@bar.com / admin123")