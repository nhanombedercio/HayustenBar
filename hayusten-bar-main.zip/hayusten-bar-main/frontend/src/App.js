import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import './App.css';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Alert, AlertDescription } from './components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './components/ui/dialog';
import { Label } from './components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Trash2, Plus, ShoppingCart, Package, BarChart3, Users, AlertTriangle } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Auth Context
const AuthContext = React.createContext();

function App() {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));

  useEffect(() => {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      // Decode token to get user info (simplified)
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        setUser({ id: payload.user_id, email: payload.email });
      } catch (e) {
        console.error('Token inválido');
        logout();
      }
    }
  }, [token]);

  const login = (token, userData) => {
    localStorage.setItem('token', token);
    setToken(token);
    setUser(userData);
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    delete axios.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      <div className="App">
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={user ? <Navigate to="/" /> : <LoginPage />} />
            <Route path="/*" element={user ? <MainApp /> : <Navigate to="/login" />} />
          </Routes>
        </BrowserRouter>
      </div>
    </AuthContext.Provider>
  );
}

// Login Component
function LoginPage() {
  const [email, setEmail] = useState('admin@bar.com');
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = React.useContext(AuthContext);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await axios.post(`${API}/auth/login`, { email, password });
      login(response.data.access_token, response.data.user);
    } catch (error) {
      setError(error.response?.data?.detail || 'Erro ao fazer login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Sistema de Bar</CardTitle>
          <p className="text-slate-600">Faça login para continuar</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@bar.com"
                data-testid="login-email-input"
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="admin123"
                data-testid="login-password-input"
              />
            </div>
            {error && (
              <Alert className="border-red-200">
                <AlertDescription className="text-red-600">{error}</AlertDescription>
              </Alert>
            )}
            <Button type="submit" className="w-full" disabled={loading} data-testid="login-submit-btn">
              {loading ? 'A entrar...' : 'Entrar'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

// Main App Component
function MainApp() {
  const { user, logout } = React.useContext(AuthContext);

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white shadow-sm border-b">
        <div className="flex justify-between items-center px-6 py-4">
          <h1 className="text-2xl font-bold text-slate-800">Sistema de Bar</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-slate-600">Olá, {user?.email}</span>
            <Button variant="outline" onClick={logout} data-testid="logout-btn">
              Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/produtos" element={<ProductsPage />} />
          <Route path="/vendas" element={<SalesPage />} />
        </Routes>
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
        <div className="flex justify-around py-3">
          <NavItem to="/" icon={BarChart3} label="Dashboard" />
          <NavItem to="/produtos" icon={Package} label="Produtos" />
          <NavItem to="/vendas" icon={ShoppingCart} label="Vendas" />
        </div>
      </nav>
    </div>
  );
}

// Navigation Item
function NavItem({ to, icon: Icon, label }) {
  const navigate = useNavigate();
  const location = useLocation();
  const isActive = location.pathname === to;
  
  const handleClick = (e) => {
    e.preventDefault();
    navigate(to);
  };
  
  return (
    <button
      onClick={handleClick}
      className={`flex flex-col items-center space-y-1 px-4 py-2 rounded-lg transition-colors ${
        isActive 
          ? 'text-blue-600 bg-blue-50' 
          : 'text-slate-600 hover:text-blue-600 hover:bg-slate-50'
      }`}
      data-testid={`nav-${label.toLowerCase()}`}
    >
      <Icon size={20} />
      <span className="text-xs">{label}</span>
    </button>
  );
}

// Dashboard Component
function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await axios.get(`${API}/dashboard/summary`);
      setSummary(response.data);
    } catch (error) {
      console.error('Erro ao carregar dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-8">A carregar...</div>;
  }

  return (
    <div className="space-y-6" data-testid="dashboard">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Vendas Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="vendas-hoje">
              {summary?.vendas_hoje?.toFixed(2)} MZN
            </div>
            <p className="text-xs text-slate-600">{summary?.num_vendas} vendas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Ticket Médio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="ticket-medio">
              {summary?.ticket_medio?.toFixed(2)} MZN
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Alertas de Stock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600" data-testid="alertas-stock">
              {summary?.alertas_stock || 0}
            </div>
            <p className="text-xs text-slate-600">produtos em ruptura</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Top Produtos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="top-produtos">
              {summary?.top_products?.length || 0}
            </div>
            <p className="text-xs text-slate-600">produtos vendidos</p>
          </CardContent>
        </Card>
      </div>

      {summary?.produtos_em_ruptura?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="text-orange-500" size={20} />
              <span>Produtos em Ruptura</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {summary.produtos_em_ruptura.map((produto, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                  <span className="font-medium">{produto.nome}</span>
                  <Badge variant="destructive">{produto.stock} unidades</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {summary?.top_products?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Produtos Mais Vendidos Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {summary.top_products.map((produto, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <div>
                    <span className="font-medium">{produto.nome}</span>
                    <p className="text-sm text-slate-600">{produto.quantidade} unidades</p>
                  </div>
                  <span className="font-bold text-green-600">{produto.valor.toFixed(2)} MZN</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Products Component
function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${API}/products`);
      setProducts(response.data);
    } catch (error) {
      console.error('Erro ao carregar produtos:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-8">A carregar produtos...</div>;
  }

  return (
    <div className="space-y-6" data-testid="produtos-page">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestão de Produtos</h2>
        <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
          <DialogTrigger asChild>
            <Button data-testid="add-produto-btn">
              <Plus size={16} className="mr-2" />
              Adicionar Produto
            </Button>
          </DialogTrigger>
          <DialogContent>
            <ProductForm onSuccess={() => { fetchProducts(); setShowAddForm(false); }} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} onUpdate={fetchProducts} />
        ))}
      </div>
    </div>
  );
}

// Product Card Component
function ProductCard({ product, onUpdate }) {
  const [showAdjustForm, setShowAdjustForm] = useState(false);

  const getStockStatus = () => {
    if (product.stock_atual <= 0) return { color: 'text-red-600', label: 'Sem stock' };
    if (product.stock_atual <= product.stock_minimo) return { color: 'text-orange-600', label: 'Stock baixo' };
    return { color: 'text-green-600', label: 'Stock OK' };
  };

  const stockStatus = getStockStatus();

  return (
    <Card className="relative">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{product.nome}</CardTitle>
          <Badge variant="outline">{product.categoria}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex justify-between">
          <span className="text-slate-600">Preço:</span>
          <span className="font-medium">{product.preco_venda.toFixed(2)} MZN</span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-600">Stock:</span>
          <span className={`font-medium ${stockStatus.color}`}>
            {product.stock_atual} unidades
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-600">Mínimo:</span>
          <span className="font-medium">{product.stock_minimo} unidades</span>
        </div>
        
        <Dialog open={showAdjustForm} onOpenChange={setShowAdjustForm}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="w-full" data-testid={`adjust-stock-${product.id}`}>
              Ajustar Stock
            </Button>
          </DialogTrigger>
          <DialogContent>
            <StockAdjustForm 
              product={product} 
              onSuccess={() => { onUpdate(); setShowAdjustForm(false); }} 
            />
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}

// Product Form Component
function ProductForm({ onSuccess }) {
  const [formData, setFormData] = useState({
    nome: '',
    categoria: '',
    preco_venda: '',
    stock_atual: '0',
    stock_minimo: '5'
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(`${API}/products`, {
        ...formData,
        preco_venda: parseFloat(formData.preco_venda),
        stock_atual: parseInt(formData.stock_atual),
        stock_minimo: parseInt(formData.stock_minimo)
      });
      onSuccess();
    } catch (error) {
      console.error('Erro ao criar produto:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <DialogHeader>
        <DialogTitle>Adicionar Produto</DialogTitle>
      </DialogHeader>
      
      <div>
        <Label htmlFor="nome">Nome do Produto</Label>
        <Input
          id="nome"
          value={formData.nome}
          onChange={(e) => setFormData({...formData, nome: e.target.value})}
          required
          data-testid="produto-nome-input"
        />
      </div>

      <div>
        <Label htmlFor="categoria">Categoria</Label>
        <Select value={formData.categoria} onValueChange={(value) => setFormData({...formData, categoria: value})}>
          <SelectTrigger data-testid="produto-categoria-select">
            <SelectValue placeholder="Seleccionar categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Cervejas">Cervejas</SelectItem>
            <SelectItem value="Vinhos">Vinhos</SelectItem>
            <SelectItem value="Espirituosas">Espirituosas</SelectItem>
            <SelectItem value="Refrigerantes">Refrigerantes</SelectItem>
            <SelectItem value="Snacks">Snacks</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="preco">Preço de Venda (MZN)</Label>
        <Input
          id="preco"
          type="number"
          step="0.01"
          value={formData.preco_venda}
          onChange={(e) => setFormData({...formData, preco_venda: e.target.value})}
          required
          data-testid="produto-preco-input"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="stock_atual">Stock Atual</Label>
          <Input
            id="stock_atual"
            type="number"
            value={formData.stock_atual}
            onChange={(e) => setFormData({...formData, stock_atual: e.target.value})}
            data-testid="produto-stock-input"
          />
        </div>
        <div>
          <Label htmlFor="stock_minimo">Stock Mínimo</Label>
          <Input
            id="stock_minimo"
            type="number"
            value={formData.stock_minimo}
            onChange={(e) => setFormData({...formData, stock_minimo: e.target.value})}
            data-testid="produto-stock-min-input"
          />
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={loading} data-testid="create-produto-btn">
        {loading ? 'A criar...' : 'Criar Produto'}
      </Button>
    </form>
  );
}

// Stock Adjust Form Component
function StockAdjustForm({ product, onSuccess }) {
  const [formData, setFormData] = useState({
    quantidade: '',
    tipo: 'AJUSTE_POSITIVO',
    motivo: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(`${API}/stock/adjust`, {
        product_id: product.id,
        quantidade: parseInt(formData.quantidade),
        tipo: formData.tipo,
        motivo: formData.motivo
      });
      onSuccess();
    } catch (error) {
      console.error('Erro ao ajustar stock:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <DialogHeader>
        <DialogTitle>Ajustar Stock - {product.nome}</DialogTitle>
        <p className="text-sm text-slate-600">Stock atual: {product.stock_atual} unidades</p>
      </DialogHeader>

      <div>
        <Label htmlFor="tipo">Tipo de Ajuste</Label>
        <Select value={formData.tipo} onValueChange={(value) => setFormData({...formData, tipo: value})}>
          <SelectTrigger data-testid="adjust-tipo-select">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="AJUSTE_POSITIVO">Aumentar Stock</SelectItem>
            <SelectItem value="AJUSTE_NEGATIVO">Reduzir Stock</SelectItem>
            <SelectItem value="QUEBRA">Registar Quebra</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="quantidade">Quantidade</Label>
        <Input
          id="quantidade"
          type="number"
          value={formData.quantidade}
          onChange={(e) => setFormData({...formData, quantidade: e.target.value})}
          required
          data-testid="adjust-quantidade-input"
        />
      </div>

      <div>
        <Label htmlFor="motivo">Motivo</Label>
        <Input
          id="motivo"
          value={formData.motivo}
          onChange={(e) => setFormData({...formData, motivo: e.target.value})}
          placeholder="Descreva o motivo do ajuste"
          required
          data-testid="adjust-motivo-input"
        />
      </div>

      <Button type="submit" className="w-full" disabled={loading} data-testid="submit-adjust-btn">
        {loading ? 'A processar...' : 'Confirmar Ajuste'}
      </Button>
    </form>
  );
}

// Sales Page Component
function SalesPage() {
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${API}/products`);
      setProducts(response.data.filter(p => p.stock_atual > 0));
    } catch (error) {
      console.error('Erro ao carregar produtos:', error);
    }
  };

  const addToCart = (product) => {
    const existingItem = cart.find(item => item.product_id === product.id);
    
    if (existingItem) {
      if (existingItem.quantidade < product.stock_atual) {
        setCart(cart.map(item =>
          item.product_id === product.id
            ? { ...item, quantidade: item.quantidade + 1, total_linha: (item.quantidade + 1) * item.preco_unit }
            : item
        ));
      }
    } else {
      setCart([...cart, {
        product_id: product.id,
        product_name: product.nome,
        quantidade: 1,
        preco_unit: product.preco_venda,
        total_linha: product.preco_venda
      }]);
    }
  };

  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.product_id !== productId));
  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity === 0) {
      removeFromCart(productId);
    } else {
      setCart(cart.map(item =>
        item.product_id === productId
          ? { ...item, quantidade: newQuantity, total_linha: newQuantity * item.preco_unit }
          : item
      ));
    }
  };

  const processSale = async () => {
    if (cart.length === 0) return;

    setLoading(true);
    try {
      await axios.post(`${API}/sales`, {
        items: cart,
        desconto: 0,
        metodo_pagamento: 'dinheiro'
      });
      
      setCart([]);
      fetchProducts(); // Refresh products to update stock
      alert('Venda processada com sucesso!');
    } catch (error) {
      alert(error.response?.data?.detail || 'Erro ao processar venda');
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter(product =>
    product.nome.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const cartTotal = cart.reduce((sum, item) => sum + item.total_linha, 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" data-testid="vendas-page">
      {/* Products Section */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Produtos Disponíveis</h2>
        
        <Input
          placeholder="Pesquisar produtos..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          data-testid="product-search-input"
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium">{product.nome}</h3>
                  <Badge variant="outline" className="text-xs">{product.categoria}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-slate-600">Stock: {product.stock_atual}</p>
                    <p className="font-medium text-green-600">{product.preco_venda.toFixed(2)} MZN</p>
                  </div>
                  <Button 
                    size="sm" 
                    onClick={() => addToCart(product)}
                    data-testid={`add-to-cart-${product.id}`}
                  >
                    <Plus size={16} />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Cart Section */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Carrinho de Compras</h2>
        
        <Card>
          <CardContent className="p-4">
            {cart.length === 0 ? (
              <p className="text-slate-500 text-center py-8">Carrinho vazio</p>
            ) : (
              <div className="space-y-3">
                {cart.map((item) => (
                  <div key={item.product_id} className="flex justify-between items-center border-b pb-3">
                    <div className="flex-1">
                      <p className="font-medium">{item.product_name}</p>
                      <p className="text-sm text-slate-600">{item.preco_unit.toFixed(2)} MZN cada</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => updateQuantity(item.product_id, item.quantidade - 1)}
                        data-testid={`decrease-${item.product_id}`}
                      >
                        -
                      </Button>
                      <span className="mx-2 font-medium" data-testid={`quantity-${item.product_id}`}>
                        {item.quantidade}
                      </span>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => updateQuantity(item.product_id, item.quantidade + 1)}
                        data-testid={`increase-${item.product_id}`}
                      >
                        +
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={() => removeFromCart(item.product_id)}
                        data-testid={`remove-${item.product_id}`}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                    <div className="ml-4 font-medium">
                      {item.total_linha.toFixed(2)} MZN
                    </div>
                  </div>
                ))}
                
                <div className="pt-3 border-t">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>Total:</span>
                    <span className="text-green-600" data-testid="cart-total">
                      {cartTotal.toFixed(2)} MZN
                    </span>
                  </div>
                </div>
                
                <Button 
                  className="w-full mt-4" 
                  onClick={processSale}
                  disabled={loading || cart.length === 0}
                  data-testid="process-sale-btn"
                >
                  {loading ? 'A processar...' : 'Finalizar Venda'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default App;