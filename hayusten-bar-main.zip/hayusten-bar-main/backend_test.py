#!/usr/bin/env python3
"""
Comprehensive Backend API Testing for Bar Management System
Tests all endpoints: auth, products, stock, sales, dashboard
"""

import requests
import sys
import json
from datetime import datetime
from typing import Dict, Any, Optional

class BarManagementAPITester:
    def __init__(self, base_url="https://barmgmt.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_results = []
        self.created_products = []

    def log_test(self, name: str, success: bool, details: str = "", response_data: Any = None):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED")
        else:
            print(f"❌ {name} - FAILED: {details}")
        
        self.test_results.append({
            "test": name,
            "success": success,
            "details": details,
            "response_data": response_data
        })

    def make_request(self, method: str, endpoint: str, data: Dict = None, expected_status: int = 200) -> tuple[bool, Dict]:
        """Make HTTP request with proper headers"""
        url = f"{self.api_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'

        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=headers, timeout=10)
            else:
                return False, {"error": f"Unsupported method: {method}"}

            success = response.status_code == expected_status
            try:
                response_data = response.json()
            except:
                response_data = {"raw_response": response.text, "status_code": response.status_code}

            return success, response_data

        except requests.exceptions.RequestException as e:
            return False, {"error": str(e)}

    def test_login(self):
        """Test login with admin credentials"""
        print("\n🔐 Testing Authentication...")
        
        success, response = self.make_request(
            'POST', 
            'auth/login',
            data={"email": "admin@bar.com", "password": "admin123"}
        )
        
        if success and 'access_token' in response:
            self.token = response['access_token']
            self.user_data = response.get('user', {})
            self.log_test("Login with admin credentials", True, f"User: {self.user_data.get('email')}")
            return True
        else:
            self.log_test("Login with admin credentials", False, f"Response: {response}")
            return False

    def test_invalid_login(self):
        """Test login with invalid credentials"""
        success, response = self.make_request(
            'POST',
            'auth/login',
            data={"email": "invalid@test.com", "password": "wrongpass"},
            expected_status=401
        )
        
        self.log_test("Login with invalid credentials (should fail)", success, 
                     "Correctly rejected invalid credentials" if success else f"Unexpected response: {response}")

    def test_products_crud(self):
        """Test product CRUD operations"""
        print("\n📦 Testing Product Management...")
        
        # Test getting products (should work with valid token)
        success, response = self.make_request('GET', 'products')
        self.log_test("Get products list", success, f"Found {len(response) if isinstance(response, list) else 0} products")
        
        # Test creating a product
        test_product = {
            "nome": "Cerveja Test",
            "categoria": "Cervejas",
            "preco_venda": 50.0,
            "stock_atual": 100,
            "stock_minimo": 10
        }
        
        success, response = self.make_request('POST', 'products', data=test_product, expected_status=200)
        if success and 'id' in response:
            product_id = response['id']
            self.created_products.append(product_id)
            self.log_test("Create product", True, f"Created product with ID: {product_id}")
            
            # Test updating the product
            update_data = {
                "nome": "Cerveja Test Updated",
                "categoria": "Cervejas",
                "preco_venda": 55.0,
                "stock_atual": 90,
                "stock_minimo": 15
            }
            
            success, response = self.make_request('PUT', f'products/{product_id}', data=update_data)
            self.log_test("Update product", success, "Product updated successfully" if success else f"Error: {response}")
            
        else:
            self.log_test("Create product", False, f"Failed to create product: {response}")

    def test_stock_management(self):
        """Test stock adjustment functionality"""
        print("\n📊 Testing Stock Management...")
        
        if not self.created_products:
            self.log_test("Stock adjustment", False, "No products available for stock testing")
            return
        
        product_id = self.created_products[0]
        
        # Test positive stock adjustment
        adjustment_data = {
            "product_id": product_id,
            "quantidade": 20,
            "motivo": "Reposição de stock",
            "tipo": "AJUSTE_POSITIVO"
        }
        
        success, response = self.make_request('POST', 'stock/adjust', data=adjustment_data)
        self.log_test("Positive stock adjustment", success, 
                     f"New stock: {response.get('novo_stock')}" if success else f"Error: {response}")
        
        # Test negative stock adjustment
        adjustment_data = {
            "product_id": product_id,
            "quantidade": 10,
            "motivo": "Correção de inventário",
            "tipo": "AJUSTE_NEGATIVO"
        }
        
        success, response = self.make_request('POST', 'stock/adjust', data=adjustment_data)
        self.log_test("Negative stock adjustment", success,
                     f"New stock: {response.get('novo_stock')}" if success else f"Error: {response}")
        
        # Test quebra (breakage)
        adjustment_data = {
            "product_id": product_id,
            "quantidade": 5,
            "motivo": "Produto danificado",
            "tipo": "QUEBRA"
        }
        
        success, response = self.make_request('POST', 'stock/adjust', data=adjustment_data)
        self.log_test("Stock breakage adjustment", success,
                     f"New stock: {response.get('novo_stock')}" if success else f"Error: {response}")

    def test_sales_system(self):
        """Test POS sales system"""
        print("\n💰 Testing Sales System...")
        
        if not self.created_products:
            self.log_test("Sales system", False, "No products available for sales testing")
            return
        
        # Get current products to use in sale
        success, products = self.make_request('GET', 'products')
        if not success or not products:
            self.log_test("Get products for sale", False, "Could not fetch products")
            return
        
        # Find a product with stock
        available_product = None
        for product in products:
            if product.get('stock_atual', 0) > 0:
                available_product = product
                break
        
        if not available_product:
            self.log_test("Find product with stock", False, "No products with stock available")
            return
        
        # Create a test sale
        sale_data = {
            "items": [
                {
                    "product_id": available_product['id'],
                    "product_name": available_product['nome'],
                    "quantidade": 2,
                    "preco_unit": available_product['preco_venda'],
                    "total_linha": 2 * available_product['preco_venda']
                }
            ],
            "desconto": 0,
            "metodo_pagamento": "dinheiro"
        }
        
        success, response = self.make_request('POST', 'sales', data=sale_data)
        self.log_test("Create sale", success,
                     f"Sale total: {response.get('total_liquido')} MZN" if success else f"Error: {response}")
        
        # Test getting sales history
        success, response = self.make_request('GET', 'sales')
        self.log_test("Get sales history", success,
                     f"Found {len(response) if isinstance(response, list) else 0} sales" if success else f"Error: {response}")

    def test_dashboard_summary(self):
        """Test dashboard KPIs"""
        print("\n📈 Testing Dashboard...")
        
        success, response = self.make_request('GET', 'dashboard/summary')
        
        if success:
            expected_fields = ['data', 'vendas_hoje', 'num_vendas', 'ticket_medio', 'alertas_stock']
            missing_fields = [field for field in expected_fields if field not in response]
            
            if not missing_fields:
                self.log_test("Dashboard summary", True, 
                             f"Sales today: {response.get('vendas_hoje')} MZN, "
                             f"Avg ticket: {response.get('ticket_medio')} MZN, "
                             f"Stock alerts: {response.get('alertas_stock')}")
            else:
                self.log_test("Dashboard summary", False, f"Missing fields: {missing_fields}")
        else:
            self.log_test("Dashboard summary", False, f"Error: {response}")

    def test_authentication_required(self):
        """Test that protected endpoints require authentication"""
        print("\n🔒 Testing Authentication Requirements...")
        
        # Temporarily remove token
        original_token = self.token
        self.token = None
        
        # Test accessing protected endpoint without token
        success, response = self.make_request('GET', 'products', expected_status=401)
        self.log_test("Products endpoint without auth (should fail)", success,
                     "Correctly rejected unauthenticated request" if success else f"Unexpected response: {response}")
        
        # Test with invalid token
        self.token = "invalid_token_123"
        success, response = self.make_request('GET', 'products', expected_status=401)
        self.log_test("Products endpoint with invalid token (should fail)", success,
                     "Correctly rejected invalid token" if success else f"Unexpected response: {response}")
        
        # Restore valid token
        self.token = original_token

    def run_all_tests(self):
        """Run complete test suite"""
        print("🚀 Starting Bar Management System API Tests")
        print(f"Testing against: {self.base_url}")
        print("=" * 60)
        
        # Test authentication first
        if not self.test_login():
            print("❌ Login failed - cannot continue with other tests")
            return False
        
        # Test invalid login
        self.test_invalid_login()
        
        # Test authentication requirements
        self.test_authentication_required()
        
        # Test all main functionality
        self.test_products_crud()
        self.test_stock_management()
        self.test_sales_system()
        self.test_dashboard_summary()
        
        # Print summary
        print("\n" + "=" * 60)
        print(f"📊 Test Summary: {self.tests_passed}/{self.tests_run} tests passed")
        print(f"Success rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All tests passed!")
            return True
        else:
            print("⚠️  Some tests failed - check details above")
            return False

def main():
    """Main test execution"""
    tester = BarManagementAPITester()
    
    try:
        success = tester.run_all_tests()
        
        # Save detailed results
        with open('/app/backend_test_results.json', 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'total_tests': tester.tests_run,
                'passed_tests': tester.tests_passed,
                'success_rate': (tester.tests_passed/tester.tests_run)*100 if tester.tests_run > 0 else 0,
                'test_details': tester.test_results
            }, f, indent=2)
        
        return 0 if success else 1
        
    except Exception as e:
        print(f"💥 Test execution failed: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())